### Reference

help = """, the following commands are available to use**

 - Hello [*optional*: fun]
 - Who are you?

## Cisco sites
-----------

 - BEMS [*optional*: folder]
 - BICs
 - Calendar
 - CALO
 - Cisco [*optional*: download / upload { *SR number* } / publish]
 - Community
 - Deloitte
 - Directory
 - Employee (BIC submition)
 - Expenses
 - Policies *or* procedures
 - PTO
 - Quicker [csone or SR # / cdets or cdets_id / RST]
 - Severity *or* escalation 
 - Stock
 - TeamUP
 - Topic            
 - Webex

 
## CUCM
----

 - CUCM certificates
 - CUCM [sql {Certificates / VPN / MoH}]
 - CUCM database
 - Capture CUCM
 - File [phone registration / CUCM Certificate regeneration / CUCM license]
 - Phone [firmware / debugs]
 - Traces collection [*optional*: CLI]


## MS
---

 - Capture [IOS / IOS XE / PCM]
 - Config [sccp / translation-rule / profile / codec]
 - CUBE [*optional*: guide / dtmf / profiles { *update / inactive / tools / info* }]
 - Debugs [*optional*: SIP / H323 / MGCP / SCCP / T1 / FXO / FXS / E1R2 / CAS]
 - File [4331 MGCP / CUBE Recording]


## Others
------

 - Messages sip [early offer / delay offer / early media]
 - template [strike / close / moh / rma / GCI / TIPBU]


*Do you have any suggestions on what should be included?* Type "request" followed by your idea!

"""

file_wrn = """

 - file phone registration
 - file 4331 MGCP
 - file CUBE Recording
 - file CUCM Certificate regeneration
 - file CUCM license

"""


cisco_wrn = """

 - Cisco
 - Cisco support / download
 - Cisco upload [*optional*: SR Number]
 - Cisco publish

"""

capture_wrn ="""**Please specify where you would like to collect the capture from:**
 - capture IOS
 - capture IOS XE
 - capture CUCM
 - capture PCM"""


cube_wrn = """

 - CUBE dtmf 
 - CUBE guide
 - CUBE profiles [tools / info / update / inactive / common]


"""

cucm_wrn = """

 - CUCM guide
 - CUCM error
 - CUCM values
 - CUCM dtmf 
 - CUCM database
 - CUCM sql [*optional*: MoH]
 

"""

template_wrn = """

 - template strike
 - template close
 - template moh
 - template rma
 - template GCI

"""

config_wrn = """

 - config sccp
 - config profile
 - config translation-rule
 - config codec

"""

phone_wrn  = """

 - phone debugs
 - phone firmware

"""

messages_wrn  = """

 - messages sip early offer
 - messages sip delay offer
 - messages sip early media

"""

bems_wrn  = """

 - BEMS 
 - BEMS folder

"""

traces_wrn  = """

 - Traces 
 - Traces CLI

"""

tac2020_wrn  = """

 - TAC 20/20  
 - TAC 20/20 Innovation

"""

#### Internal Cisco sites 
#bdb = "[BDB Home](https://bdb.cisco.com)"
#bdb_dashboard = "[BDB Dashboard](https://scripts.cisco.com/mamorten/borg/borg_tools/bdsl.html?gw=#)"
bics = """[BICs Etherpad](http://tac-etherpad/cucm-Mericas-bic)"""

calendar = "[UCS Calendar](https://csone.lightning.force.com/c/UCSApp.app)"

calo = "[CALO](http://calo-mxc-cfme.cisco.com)"

cisco = "[Cisco](https://www.cisco.com)"

cisco_publish  = "[Cisco File Publish](https://swds.cisco.com/cgi-bin/sfp/specialpub.cgi)"

deloitte = "[Deloitte](https://dpass.dtomx1106.deloitte.com.mx/BPO1CSM93)"

expenses = "[Expense Report](https://concur.cisco.com)"

community = "[Mex-collab Community](https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=4f1d8f4c-57e3-4164-88bd-7c1c640b7442)"

pto = "[PTO](http://mypto.cloudapps.cisco.com/mypto/mobile/view)"

teamup = "[TeamUP](https://globalcxcentersstrategy.cisco.com)"

webex  = "Start meeting in your [Personal Room](https://cisco.webex.com/join/{0})  -  https://cisco.webex.com/join/{1}"

employee_services = "[Employee Services (Submit BICs)](https://wwwin-hrprd.cisco.com/OA_HTML/RF.jsp?function_id=48067&resp_id=50615&resp_appl_id=800&security_group_id=17&lang_code=US&oas=ueEPWboFKc3DMFxnSURGAQ)"

directory = "[Cisco Directory](https://directory.cisco.com/dir/)"

cisco_stock = "[Cisco Stock](https://www.marketwatch.com/investing/stock/csco)"

bems  = "[BEMS](https://clpsvs.cloudapps.cisco.com/services/clip/main#eyJzY3JlZW4iOiJlbmdMaXN0Iiwic2VydmljZUlkIjo3MCwiZW5nTGlzdCI6e319)"

bems_folder = """\\\\\\rcdn9-netapp-ns\\workgroup\\ipcbu-trace\\Published\\DDTS\\683411376"""

calo = "[CALO](http://calo-mxc-cfme.cisco.com)"

cisco_support = "[Cisco Download Software](https://www.cisco.com/c/en/us/support/index.html)"

community = "[Mex-collab Community](https://apps.na.collabserv.com/communities/service/html/communityoverview?communityUuid=4f1d8f4c-57e3-4164-88bd-7c1c640b7442)"

policies_and_procedures = "[Policies and procedures](http://policycentral.cloudapps.cisco.com/cppc/home)"

topic  = "[Topic](https://srchui.cloudapps.cisco.com/srchui/jsp/search.jsp)"

sev_and_esc = "[Severity and Escalation Guidelines](https://www.cisco.com/c/dam/en_us/about/doing_business/legal/service_descriptions/docs/Cisco_Severity_and_Escalation_Guidelines.pdf)"


uploader = "https://cway.cisco.com/csc/"
#https://cway.cisco.com/csc/?requestID=683548186

webex  = "Start meeting in your [Personal Room](https://cisco.webex.com/join/{0})  -  https://cisco.webex.com/join/{1}"
 
 

##### Tec notes and links

   # Debugs
debugs  = """

    configure terminal
    service timestamps debug datetime local msec
    service timestamps log datetime local msec
    service sequence
    no logging console
    no logging monitor
    no logging rate-limit
    no logging queue-limit
    voice iec syslog
    logging buffer 3000000 debug
    end
"""


debugs_sip = """            
    debug ccsip messages
    debug voice ccapi inout"""

debugs_h323 = """
    debug h225 asn1
    debug h245 asn1
    debug voice ccapi inout"""

debugs_mgcp = """
    debug mgcp packet
    debug voice ccapi inout"""

debugs_t1 = """
    debug isdn q931
    debug voice ccapi inout
    debug isdn q921"""

debugs_fxo = """
    debug vpm signal
    debug voice vtsp all
    debug voice ccapi inout"""

debugs_sccp = """
    debug voip application stcapp all
    debug sccp event
    debug voice ccapi inout"""


debugs_wrn = """
 - debugs  -  GW Configuration to prepare router for debugging
 - debugs [ SIP \ H323 \ MGCP \ SCCP \  T1 \ FXO \ FXS \ E1R2 \ CAS]"""

   # Captures


capture_ios = """**IOS Packet Capture:**
    configure terminal
        ip traffic-export profile TAC mode capture
            bidirectional
        exit
        interface GigabitEthernet0/0
            ip traffic-export apply TAC size 10000000
        end
    traffic-export interface GigabitEthernet0/0 clear
    traffic-export interface GigabitEthernet0/0 start
                
                   --MAKE CALL--

    traffic-export interface GigabitEthernet0/0 stop
    traffic-export interface GigabitEthernet0/0 copy tftp://[*TFTP IP Address*]/tac-sniffer.pcap

You may want to take a look at: https://www.cisco.com/c/en/us/support/docs/ios-nx-os-software/ios-embedded-packet-capture/116045-productconfig-epc-00.html"""

capture_ios_xe = """**IOS XE Packet Capture:**

    monitor capture CAP interface GigabitEthernet0/0/0 both
    monitor capture CAP match ipv4 any any
    monitor capture CAP start

                  ---MAKE CALL---

    monitor capture CAP stop
    show monitor capture CAP buffer brief
    show monitor capture CAP buffer detailed
  
    monitor capture CAP export tftp://[*TFTP IP Address*]/CAP.pcap

You may want to take a look at: https://www.cisco.com/c/en/us/support/docs/ios-nx-os-software/ios-embedded-packet-capture/116045-productconfig-epc-00.html"""

capture_cucm = """**CUCM Packet Capture:**

Capturing all traffic:
    utils network capture eth0 file packets count 100000 size all 


Capturing traffic based on host:
    utils network capture eth0 file packets count 100000 size all host ip X.X.X.X


You may want to take a look at: https://supportforums.cisco.com/t5/collaboration-voice-and-video/packet-capture-on-cucm-appliance-model/ta-p/3118507"""

capture_pcm = """**PCM Capture:**

    voice pcm capture buffer 200000
    voice pcm capture destination flash:pcm.dat
    test voice port 0/1/0:23.10 pcm cap fff

        --MAKE CALL--

    test voice port 0/1/0:23.10 pcm-dump disable
    voice pcm capture buffer 0
    no voice pcm capture destination

    copy flash:pcm.dat tftp


For a triggered PCM or to decode a PCM capture, please go to [PCET](http://pcet.cisco.com)"""
   
    # Traces
traces = "[How to collect CUCM Traces](http://www.cisco.com/c/en/us/support/docs/unified-communications/unified-communications-manager-callmanager/200787-How-to-Collect-Traces-for-CUCM-9-x-10-x.html)"

traces_cli = """

From CUCM CLI:

    file [list/get] activelog [path]

E.g.: 

    file get activelog cm/trace/ccm/sdl/SDL*
    file get activelog cm/trace/ccm/calllogs/calllogs*
    file get activelog cm/trace/ccm/sdi/ccm*


For other [trace location in CLI](https://supportforums.cisco.com/t5/collaboration-voice-and-video/communications-manager-rtmt-trace-locations-in-cli/ta-p/3122176)

"""



    # CUBE
cube_dtmf = "[DTMF Interworking](https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/voice/cube/configuration/cube-book/dtmf-relay.html)"
cube_configuration = "[CUBE Configuration Guide](https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/voice/cube/configuration/cube-book.html)" 
cube_profiles_tools = """

[SIP Profile generator](http://cantor.cisco.com/sip-profiles-gen.html)

[SIP Profile test](http://cantor/sip-profiles.html)

"""

cube_profiles_common =  "[Common used SIP-Profiles](https://www.cisco.com/c/en/us/support/docs/unified-communications/unified-border-element/118825-technote-sip-00.html)" 

cube_profiles_inactive = """ SIP Profile
    
    configure terminal

    voice class sip-profiles 1
        request any sdp-header Audio-Attribute modify "a=inactive" "a=sendrecv"
        request any sdp-header Audio-Attribute modify "a=recvonly" "a=sendrecv"
        request any sdp-header Audio-Attribute modify "a=sendonly" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=inactive" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=recvonly" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=sendonly" "a=sendrecv"
        exit

   
    dial-peer voice 1001 voip
        voice-class sip profiles 1
        exit

    voice service voip
        sip
            sip-profiles 1
"""

cube_profiles_update = """ SIP Profile
    
    configure terminal

    voice class sip-profiles 1
        request ANY sip-header Allow-Header modify ", UPDATE" ""
        response ANY sip-header Allow-Header modify ", UPDATE" ""
        exit

    dial-peer voice 1001 voip
        voice-class sip profiles 1
        exit

    voice service voip
        sip
            sip-profiles 1
"""



cube_profiles_wrn = """

 - CUBE profiles common 
 - CUBE profiles inactive
 - CUBE profiles info
 - CUBE profiles update
 - CUBE profiles tools

"""

cube_profiles_info = """To create SIP Profiles you can use: 

[SIP Profile generator](http://cantor.cisco.com/sip-profiles-gen.html)

[SIP Profile test](http://cantor/sip-profiles.html)

The most common ones are explained in [Common used SIP-Profiles](https://www.cisco.com/c/en/us/support/docs/unified-communications/unified-border-element/118825-technote-sip-00.html)

For example:

    configure terminal

    voice class sip-profiles 1
        request ANY sip-header Allow-Header modify ", UPDATE" ""
        response ANY sip-header Allow-Header modify ", UPDATE" ""
        exit
    
    voice class sip-profiles 2
        request any sdp-header Audio-Attribute modify "a=inactive" "a=sendrecv"
        request any sdp-header Audio-Attribute modify "a=recvonly" "a=sendrecv"
        request any sdp-header Audio-Attribute modify "a=sendonly" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=inactive" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=recvonly" "a=sendrecv"
        response any sdp-header Audio-Attribute modify "a=sendonly" "a=sendrecv"
        exit

For more information go to [CUBE Config guide: SIP-Profiles](https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/voice/cube/configuration/cube-book/voi-sip-param-mod.html)

"""

### CUCM 

cucm_error = "[CUCM Error messages](https://www.cisco.com/c/en/us/td/docs/voice_ip_comm/cucm/err_msgs/10_x/ccmalarms1001.html)"
cucm_values  = "[CUCM Enum values](https://techzone.cisco.com/t5/General/Some-CUCM-Enum-Values/td-p/749825)"

cucm_dtmf = """ DTMF values e.g. party1DTMF(3 2 101 1) party2DTMF(4 2 101 1)

Value A= DTMF reception preference specified in the device record enum DTMFConfig

    BestEffort = 1
    PreferOOB = 2
    Prefer2833 = 3
    PreferBoth = 4
 

Value B= DTMFMethod( DTMF capability the endpoint can support) enum DTMFMethod

    NoDTMF = 0
    OOB = 1
    RFC2833 = 2
    OOB_RFC2833 = 3
    UnknownDTMF = 4


Value C = RFC2833 payload number


Value D = Want DTMF Reception

"""
cucm_sql_certificates = """ SQL certificates

List CallManager and CallManager-trust
    run sql ccm select c.servername as Server_Name, c.serialnumber as Serial_Number, tcs.name as Cert_Type, c.subjectname as Subject_Name, c.issuername as Issuer from certificate as c inner join certificateservicecertificatemap as cscm on c.pkid = cscm.fkcertificate inner join typecertificateservice as tcs on cscm.tkcertificateservice = tcs.enum where tcs.enum = 3 or tcs.enum = 4

List Tomcat and tomcat-trust
    run sql ccm select c.servername as Server_Name, c.serialnumber as Serial_Number, tcs.name as Cert_Type, c.subjectname as Subject_Name, c.issuername as Issuer from certificate as c inner join certificateservicecertificatemap as cscm on c.pkid = cscm.fkcertificate inner join typecertificateservice as tcs on cscm.tkcertificateservice = tcs.enum where tcs.enum = 5 or tcs.enum = 6

List of type of certificate service
    run sql select * from typecertificateservice

Paths from root access
    CallManager-Trust /usr/local/cm/.security/CallManager/trust-certs
    IPSEC-trust       /usr/local/platform/.security/ipsec/trust-certs
    Tomcat-trust      /usr/local/platform/.security/tomcat/trust-certs

Mixed-mode or Non-secure Cluster
    run sql select paramname,paramvalue from processconfig where paramname='ClusterSecurityMode'

Delete certs from root access using IP
    delete FROM CERTIFICATE where ipv4address in ("10.xx.xx.1","10.xx.xx.2");
    delete FROM certificateprocessnodemap where ipv4address in ("10.xx.xx.1","10.xx.xx.2")

Delete certs from root access using serial number
    delete from certificate where serialnumber='<your serial number here with lowercase letters>';
    delete from certificate where serialnumber='<your serial number here with lowercase letters>'

"""
cucm_certs = "[CUCM Certs regeneration](https://www.cisco.com/c/en/us/support/docs/unified-communications/unified-communications-manager-callmanager/214231-certificate-regeneration-process-for-cis.html)"

cucm_database = """

Important CLI commands for DB Replication

    show network cluster
    run sql select * from processnode

    utils dbreplication status
    utils dbreplication runtimestate
    utils diagnose test
    utils service list
    utils create report database

    file list activelog cm/trace/dbl/ date detail
    file view activelog cm/log/informix/ccm.log
    file view install system-history.log



"""



cucm_srnd_11 = "[CUCM 12 SRND](https://www.cisco.com/c/en/us/td/docs/voice_ip_comm/cucm/srnd/collab12/collab12.html)"

cucm_sql_moh = """

**To get IP Address and Port number per MMoH file:**

    run sql SELECT M.pkid, D.name devicename, M.mohaudiosourceid, M.multicastaddress, M.multicastport, M.maxhops, C.name codec FROM mohservermulticastinfo AS M, DEVICE AS D, OUTER typemohcodec AS C WHERE M.fkdevice = D.pkid AND M.tkmohcodec = C.enum



**To get MoH audio source used in every device:**

*from device*
    run sql select networkholdmohaudiosourceid,userholdmohaudiosourceid,description,name from device
 
*from line / DN*
    run sql select networkholdmohaudiosourceid,userholdmohaudiosourceid,dnorpattern from numplan
 
*from common device config*
    run sql select holdpartynetworkholdmohaudiosourceid,holdpartyuserholdmohaudiosourceid,name from commondeviceconfig

 

**To get device using specific MOH source:**

*from Device*
    run sql select networkholdmohaudiosourceid,userholdmohaudiosourceid,description,name from device where networkholdmohaudiosourceid=15

*from line / DN*
    run sql select networkholdmohaudiosourceid,userholdmohaudiosourceid,dnorpattern from numplan where networkholdmohaudiosourceid=15
 
"""

cucm_sql_Trunk = """
SIP Trunk:

    run sql select siptrunkdestination.address AS IP_Address, device.name, device.description, siptrunkdestination.port AS dest_port, securityprofile.incomingport AS incoming_port from siptrunkdestination, sipdevice, device, securityprofile where siptrunkdestination.address='10.88.247.161' AND sipdevice.fkdevice = device.pkid AND siptrunkdestination.fksipdevice = sipdevice.pkid AND device.fksecurityprofile = securityprofile.pkid

"""
 
cucm_sql = "[CUCM SQL Queries](https://techzone.cisco.com/t5/General/CUCM-Sql-Queries/ta-p/988954#toc-hId-1248652838)"

cucm_sql_wrn = """

 - CUCM SQL
 - CUCM SQL MoH

"""




#### TEMPLATES



template_moh = """

 - Can you please explain for me the issue in detail?
 - Are you using Unicast or Multicast MoH?
 - What device is in charge of streaming the MoH?
 - Was this working before? If yes, what changes were made before the issue started to happen?
 - Is the issue happening with all the calls, in other words, does the issue happen for calls between 2 internal numbers and calls between an internal and a external party?
 - If the issue just happens between an internal and a external phone, please provide me with the Call Flow for that scenario  e.g. Phone -> (SCCP) -> CUCM -> (SIP) -> CUBE -> (SIP) -> ITSP
 - What version of CUCM do you have?  9.1.2.XXXXXX-XX
 - How many servers are there in the cluster including the publisher?

Note: If you are not using the default Audio Source of CUCM, please verify that the audio file has been uploaded to all the servers of the Cluster. If you have just uploaded a new file on the servers and associated to an Audio Source, after uploading the file to each server, please restart the IPVMS service under Cisco Unified Serviceability page, go to Tools - Control Center - Feature Services, select each one of the servers, then select the Service Cisco IP Voice Media Streaming App and click on Restart. Please remember to restart the IPVMS service on each server


"""

template_rma = """

**Shipping Details**
 - Company name:
 - Street and number:
 - Town/City:
 - Zip/Postal code:
 - Province/State:
 - Country:

 
**Contact Details**
 - Contact Person:
 - Contact Number:
 - Contact Email:

 
**Product Details**
 - Product ID:
 - Part S/N:
 - Chassis S/N:
 - Contract Number:


**SLA DETAILS**
 - Site Access Available after 5:00 P.M. (local time): (Yes/No)
 - Manned Site: (Yes/No)
 - Leave Parts with Security: (Yes/No)
 - Requested Part Delivery Time (schedule another time)? (Date & Time)

As soon as I receive this information, I will process the RMA and send you the RMA number.

Feel free to contact me if you have any questions."""

 
template_strike = """

Hello,

I have not heard from you in a while, I understand that some other issues might have taken priority over this one, and I don't want to add more pressure on you, but we cannot have a case opened this long if nobody is working on it, so I think that the best way to proceed is to close this case, please remember that you can open a new one at a more convenient time, when you are able to continue working on this, so, I'll go ahead and close this case by EOB if there are no progress updates, it's been a pleasure working with you, and do not hesitate to contact TAC again if you have further questions or need further assistance.

Best regards,

"""

template_close = """

Hello,

It was a pleasure working with you.

If you need further assistance or have any other issues, please do not hesitate to contact Cisco TAC frontline at 1800-553-2447.

Best regards,"""


template_gci = """
PROBLEM DESCRIPTION:

==============================

SOFTWARE/HARDWARE VERSION:

==============================

CALL FLOW:

==============================

SYMPTOMS:

==============================

BUSINESS IMPACT:

==============================

RECENT CHANGES:

==============================

TAC FINDINGS / SUMMARY:

==============================

ACTION PLAN:

==============================
"""

template_tipbu ="[TIPBU BEMS Questionaire](https://techzone.cisco.com/t5/General/TIPBU-BEMS-Questionnaire-Revised/ta-p/1101813)"


config_sccp = """SCCP Media Resource configuration

    sccp local FastEthernet/Loopback X/Y
    sccp ccm 10.122.141.40 identifier 1 version 7.0       ///  primary CUCM  IP
    sccp ccm 10.88.247.131 identifier 2 version 7.0       ///  secondary CUCM  IP
    sccp
 
    sccp ccm group 1
        associate ccm 1 priority 1
        associate ccm 2 priority 2
        associate profile 1 register CFB           ///  CFB  name in CUCM
        associate profile 6 register XCODER        ///  transcoder  name in CUCM
        associate profile 2 register MTP_GW

    dspfarm profile 1 conference
        codec g711ulaw
        codec g711alaw
        codec g729ar8
        codec g729abr8
        maximum sessions 2
        associate application SCCP
        no shutdown
  
    dspfarm profile 6 transcode
        codec g711ulaw
        codec g711alaw
        codec g729ar8
        codec g729abr8
        codec g729r8
        maximum sessions 4
        associate application SCCP
        no shut

    dspfarm profile 2 mtp
        codec g711ulaw
        maximum sessions software 4
        associate application SCCP
        no shut

"""

 

config_codec= """Voice class codec configuration

    voice class codec 1
        codec preference 1 g711alaw
        codec preference 2 g711ulaw
        codec preference 3 g729r8   

    dial-peer voice 1034 voip
        voice-class codec 1
"""

 

config_translation = """Voice translation profile configuration

    voice translation-rule 1
        rule 1 /^9/ //

    voice translation-profile PSTN
        translate called 1

    dial-peer voice 1034 voip
        translation-profile outgoing PSTN

"""

 
### IP Phone

phone_debugs = "[IP Phone Debugs](https://wiki.cisco.com/display/TRIAGE/Phones)"

phone_firmware = "[IP Phone ES Firmware](https://wwwin-endpoint-sustaining-server.cisco.com/)"


 
