.. _deprecated:

Deprecated Requests Utilities
=============================

Requests has `decided`_ to deprecate some utility functions in 
:mod:`requests.utils`. To ease users' lives, they've been moved to 
:mod:`requests_toolbelt.utils.deprecated`.

.. automodule:: requests_toolbelt.utils.deprecated
    :members:

.. _decided: https://github.com/kennethreitz/requests/issues/2266
