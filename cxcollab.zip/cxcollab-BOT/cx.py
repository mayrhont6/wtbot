from itty import *

import urllib2
import json
import requests
import links 
import random
import re
import unicodedata

from toolbelt.requests_toolbelt.multipart.encoder import MultipartEncoder
#from encoder import MultipartEncoder

proxy = "http://proxy.esl.cisco.com"
os.environ['http_proxy'] = proxy
os.environ['HTTP_PROXY'] = proxy
os.environ['https_proxy'] = proxy
os.environ['HTTPS_PROXY'] = proxy

def sendSparkGET(url):
    """
    This method is used for:
        -retrieving message text, when the webhook is triggered with a message
        -Getting the username of the person who posted the message if a command is recognized
    """
    #print "\n\nin Function..." 
    #payload = open("request.json")   
    
    r = requests.get(url, headers={"Authorization" : bearer, 'Content-Type': 'application/json', 'Accept': "application/json"})

    #request = urllib2.Request(url,
    #                        headers={"Authorization" : "Bearer " + bearer,
    #                                 "Accept" : "application/json",
    #                                 "Content-Type":"application/json"})
    
    # request = urllib2.Request(url,
    #                        headers={"Authorization" : "Bearer " + bearer,
    #                                 "Content-Type":"application/json"})

    #request.add_header("Authorization: ", "Bearer " + bearer)
    #print "\n\nAbout to read... " + str(request)
    #contents = urllib2.urlopen(request).read()
    #print "\n\nContent: " + contents + "\nsendSparkGET "
    return r.text
    #return null    

def sendSparkPOST(url, data):
    """
    This method is used for:
        -posting a message to the Spark room to confirm that a command was received and processed
    """
    #request = urllib2.Request(url, json.dumps(data),
    #                        headers={"Accept" : "application/json",
    #                                 "Content-Type":"application/json"})
    #request.add_header("Authorization", "Bearer "+ bearer)

    #contents = urllib2.urlopen(request).read()
    
    #print data['roomId']
    data = json.dumps(data)

    r = requests.post(url, data = data, headers={"Authorization" : bearer, 'Content-Type': 'application/json', 'Accept': "application/json"})    
    

    #r = requests.post(url, headers={"Authorization" : bearer, 'Content-Type': 'application/json', 'Accept': "application/json"}) 
    
    return r.text
    

def sendSparkPOST_file(url, room, text, file_name, file_path, file_type):
    """
    This method is used for:
        -posting a message to the Spark room to confirm that a command was received and processed
    """

    m = MultipartEncoder({'roomId': room,
                      'text': text,
                      'files': (file_name, open(file_path, 'rb'),
                      file_type)})

    r = requests.post('https://api.ciscospark.com/v1/messages', data=m,
                  headers={'Authorization': bearer ,
                  'Content-Type': m.content_type})

    return r.text

@post('/')
def index(request):
    #print "\nMain function"
    webhook = json.loads(request.body)
      
    # Get message sent to the BOT
    #print "\nsendSparkGET "+ str(webhook) 
    result = sendSparkGET('https://api.ciscospark.com/v1/messages/{0}'.format(webhook['data']['id']))
    result = json.loads(result)

    # Get email from the sender
    user = webhook['data']['personEmail']
    user = user.split('@')[0]
    
    user_id = webhook['data']['personId']
    msg = None
    
    #print result
    #request = urllib2.Request('https://api.ciscospark.com/v1/contents/Y2lzY29zcGFyazovL3VzL0NPTlRFTlQvOGZhZGQwNTAtZGZiZi0xMWU3LWFlZTktOWI4YzFjMDRhNzIwLzA')
    #request.add_header("Authorization", "Bearer " + bearer)
    #request.get_method = lambda : 'HEAD'
    #print urllib2.urlopen(request).info()
   
    # If BOT is not the one sending the message    
    if user != bot_name:
        
        # Change message to lower case so as to be non-case sensitive
        in_message = result.get('text', '').lower()

        # Take out BOT name from message content 
        in_message = in_message.replace(bot_name, '')
        #print in_message
        in_message = in_message.replace('  ', '')  

        # Start looking for a known command 
        if "who are you" in in_message:
            msg = "I'm CXcollab bot! \n\n Run 'cxcollab help' or 'cxcollab ?'  to learn more.. "
            
        elif "hello" in in_message or "hi" in in_message :
            user_id = sendSparkGET('https://api.ciscospark.com/v1/people/{0}'.format(user_id))
            user_id = json.loads(user_id)
            user_id = user_id.get('nickName', '')
            if "fun" in in_message:
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], "Hello " + user_id + ", how can I help?"  , "hello.gif", "Important_Documents/hello.gif", 'image/gif')
                f = open('log.txt', 'a+')
                f.write( webhook['data']['created'][:19] + '  Print to ' + user + ' ' + in_message + '\n')
                f.close()
            else:
                msg = "Hello " + user_id + ", how can I help?"
                   
        elif 'repeat' in in_message:
            message = result.get('text').split('repeat')[1].strip(" ")
            if len(message) > 0:
                msg = "'{0}'".format(message)
            else:
                msg = "Nothing to repeat..."
        
        elif "request" in in_message[0:8]:
            f = open('request.txt', 'a+')
            f.write(webhook['data']['created'][:19] + ' ' + user + ' ' + in_message + '\n')
            f.close()
            msg = "**Thanks for your feedback**"

	# BIRTHDAY

	elif "birthday" in in_message:

            text = str.split(str(in_message))

	    if len (text) == 2:
               meses = ["january","february","march","april","may","june","july","august","september","october","november","december"]
	       
	       if text[1] in meses:
		  msg = "Test birthday "
                  file_name = text[1] + ".png"
                  file_path = "Important_Documents/birthday/" + file_name
                  print "Sending "+ file_name
                  sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text[1], file_name, file_path, 'image/png')	
		

        # Internal Cisco sites

        elif "ruleta" in in_message[0:7]:
            msg = in_message.split(' ')
            #print "\n" + str(len(msg)) + str(random.randint(1,len(msg)-1)) 
            msg = msg[2:]
            if len(msg) == 0:
               msg = [ "alegarc2", "belsanch" ,"cesavila", "danimora", "fregonza", "jmedinao", "osmelend", "victogut"]
            random.shuffle(msg)
            index = random.randint(0,len(msg)-1)
            #random.shuffle(msg)
            print "\n Lista reacomodada" + str(msg) + " Elemento " + str(index + 1)
            msg = msg[index]
            #msg = " <@all> - " + msg[index]
            #msg = "<@personEmail:" + msg[index] + "@cisco.com>"
            

        elif "bems" in in_message:
            if "folder" in in_message:
                msg = links.bems_folder            

            elif '?' in in_message:
                msg = links.bems_wrn

            else:
                msg = links.bems
            
        elif 'cisco' in in_message:
            if 'supp' in in_message or 'download' in in_message:
                msg = links.cisco_support
            elif 'upload' in in_message:
                upload_url = result.get('text').split('upload')[1].strip(" ")
                if len(upload_url) > 0:
                    msg = links.uploader + "?requestID=" + upload_url
                else:
                    msg = links.uploader
           
            elif '?' in in_message:
                msg = links.cisco_wrn

            else:
                msg = links.cisco
        
       #            sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_type)

        elif "expense" in in_message:
            msg = links.expenses
       
        elif "bic" in in_message:
            msg = links.bics
       
        elif "calendar" in in_message:
            msg = links.calendar

        elif "community" in in_message:
            msg = links.community

        elif "deloitte" in in_message:
            msg = links.deloitte

        elif "policies" in in_message or "procedures" in in_message:
            msg = links.policies_and_procedures

        elif "teamup" in in_message:
            msg = links.teamup
        
        elif "topic" in in_message:
            msg = links.topic

        elif "pto" in in_message:
            msg = links.pto

        elif "severity" in in_message or "escalation" in in_message:
            msg = links.sev_and_esc

        elif "webex" in in_message:
            msg = links.webex.format(user, user)

        elif "file" in in_message[0:5]:
            if "phone registration" in in_message or "phone boot" in in_message :
                text = "Phone boot up process"
                file_name = "Register Process.pcapng"
                file_path = "Important_Documents/Register Process.pcapng"
                print "Sending Register Process.pcapng"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'capture/pcap')
            elif "4331 mgcp" in in_message:
                text = "4331 MGCP - PRI sample configuration"
                file_name = "4331 MGCP PRI.txt"
                file_path = "Important_Documents/4331 MGCP PRI.txt"
                print "Sending 4331 MGCP PRI.txt"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'text/txt')
            elif "recording" in in_message:
                text = "CUBE Recording sample configuration"
                file_name = "Show run recording CUBE.txt"
                file_path = "Important_Documents/Show run recording CUBE.txt"
                print "Sending Show run recording CUBE.txt"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'text/txt')
            elif "certificate" in in_message:
                text = "CUCM Certificate regeneration"
                file_name = "Certificate Regeneration.docx"
                file_path = "Important_Documents/Certificate Regeneration.docx"
                print "Sending Certificate Regeneration.docx"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
            elif "cucm license" in in_message:
                text = "License installation CUCM lab"
                file_name = "License CUCM lab.docx"
                file_path = "Important_Documents/License CUCM lab.docx"
                print "Sending License CUCM lab.docx"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')
             
            elif "?" in in_message or "help" in in_message:
                msg = links.file_wrn     
            else:
                msg = links.file_wrn


        elif "phone" in in_message:
            if "escalation" in in_message or "debug" in in_message :
                msg = links.phone_debugs
            elif " es" in in_message or "firmware" in in_message or " fw" in in_message:
                msg = links.phone_firmware
            elif "?" in in_message or "help" in in_message:
                msg = links.phone_wrn     
            else:
                msg = links.phone_wrn
           
        elif "message" in in_message:
            if "sip early media" in in_message:
                text = "SIP Early Media"
                file_name = "Early Media.png"
                file_path = "Important_Documents/Early Media.png"
                print "Sending Early Media.png"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'image/png')
            elif "sip early offer" in in_message or "sip eo" in in_message:
                text = "SIP Early Offer"
                file_name = "Early Offer.png"
                file_path = "Important_Documents/Early Offer.png"
                print "Sending Early Offer.png"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'image/png')
            elif "sip delay offer" in in_message or "sip do" in in_message:
                text = "SIP Delay Offer"
                file_name = "Delayed Offer.png"
                file_path = "Important_Documents/Delayed Offer.png"
                print "Sending Delayed Offer.png"
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], text, file_name, file_path, 'image/png')
            elif "?" in in_message or "help" in in_message:
                msg = links.messages_wrn     
            else:
                msg = links.messages_wrn

        elif "debugs" in in_message or "debug" in in_message:
            if "sip" in in_message:
                msg = "**SIP Debugs:**" + links.debugs_sip
            elif "h323" in in_message:
                msg = " **H323 Debugs:**" +links.debugs_h323
            elif "mgcp" in in_message:
                msg = "**MGCP  Debugs:**" + links.debugs_mgcp
            elif "fxo" in in_message or "e1r2" in in_message or "r2" in in_message or "cas" in in_message or "fxs" in in_message :
                msg = "**Enable Debugs:**" + links.debugs_fxo
            elif "t1" in in_message or "e1" in in_message or "pri" in in_message :
                msg = "**PRI Debugs:**" + links.debugs_t1
            elif "sccp" in in_message:
                msg = "**SCCP  Debugs:**" + links.debugs_sccp
            elif "?" in in_message or "help" in in_message:
                msg = "**debug help:**" + links.debugs_wrn
            else:
                msg = "Debug setup" + links.debugs
        
        elif "capture" in in_message:
            if "ios xe" in in_message or "xe" in in_message or "4k" in in_message :
                msg = links.capture_ios_xe
            elif "ios" in in_message:
                msg = links.capture_ios
            elif "pcm" in in_message:
                msg = links.capture_pcm
            elif "cucm" in in_message or " cm" in in_message:
                msg = links.capture_cucm
            else:
                msg = links.capture_wrn
  
        elif "trace" in in_message:
            if " cli" in in_message:
                msg = links.traces_cli            

            elif '?' in in_message:
                msg = links.traces_wrn

            else:
                msg = links.traces


	
        elif "cube" in in_message:
            if "dtmf" in in_message:
                msg = links.cube_dtmf
            elif "configuration" in in_message or "guide" in in_message:
                msg = links.cube_configuration
            elif "sip-profile" in in_message or "profile" in in_message:
                if "tool" in in_message:
                    msg = links.cube_profiles_tools
                elif "common" in in_message:
                    msg = links.cube_profiles_common
                elif "update" in in_message:
                    msg = links.cube_profiles_update 
                elif "audio" in in_message or "inactive" in in_message:
                    msg = links.cube_profiles_inactive 
                elif "?" in in_message or "help" in in_message:
                    msg = links.cube_profiles_wrn
                else:
                    msg = links.cube_profiles_info   
            elif "?" in in_message or "help" in in_message:
                msg = links.cube_wrn     
            else:
                msg = links.cube_configuration

        elif "cucm" in in_message:
            if "dtmf" in in_message:
                msg = links.cucm_dtmf
            elif "database" in in_message:
                msg = links.cucm_database
            elif "certificates" in in_message:
		msg = links.cucm_certs
            elif "sql" in in_message or "query" in in_message:
                if "moh" in in_message:
                    msg = links.cucm_sql_moh
                elif "certificates" in in_message:
                    msg = links.cucm_sql_certificates
                elif "?" in in_message or "help" in in_message:
                    msg = links.cucm_sql_wrn
                else:
                    msg = links.cucm_sql  
            elif "?" in in_message or "help" in in_message:
                msg = links.cucm_wrn     
            else:
                msg = links.cucm_srnd_11

        elif "template" in in_message:
            if "close" in in_message :
                msg = links.template_close
            elif "gci" in in_message:
                msg = links.template_gci
            elif "strike" in in_message:
                msg = links.template_strike
            elif "rma" in in_message:
                msg = links.template_rma
            elif "moh" in in_message:
                msg = links.template_moh
            elif "?" in in_message or "help" in in_message:
                msg = links.template_wrn     
            else:
                msg = links.template_wrn

        elif "config" in in_message:
            if "sccp" in in_message :
                msg = links.config_sccp
            elif "profile" in in_message:
                msg = links.cube_profiles_update
            elif "translation" in in_message:
                msg = links.config_translation
            elif "codec" in in_message:
                msg = links.config_codec
            elif "?" in in_message or "help" in in_message:
                msg = links.config_wrn     
            else:
                msg = links.config_wrn


        elif "help" in in_message or "?" in in_message :
            user_id = sendSparkGET('https://api.ciscospark.com/v1/people/{0}'.format(user_id))
            user_id = json.loads(user_id)
            user_id = user_id.get('nickName', '')            
            msg = "**" + user_id + ", " + links.help

        elif "calo" in in_message:
            msg = links.calo

        elif "staffer" in in_message:
            msg = links.staffer

                  
        else:
            msg = "'" + in_message + "'" + " is not a recognized instruction, please try again, you may want to run: \n'cxcollab ?' or 'cxcollab help' for assistance" 

        if msg != None:
            #print "\n\nmsg diff to None, user:" + user  + "\n\n"
            ##sendSparkPOST("https://api.ciscospark.com/v1/messages", {"roomId": webhook['data']['roomId'], "text": msg, "markdown": msg_marked })
            sendSparkPOST("https://api.ciscospark.com/v1/messages", {"roomId": webhook['data']['roomId'], "markdown": msg })
            print "To " + user + ": " + in_message
            f = open('log.txt', 'a+')
            f.write( webhook['data']['created'][:19] + '  Print to ' + user + ' ' + in_message + '\n')
            f.close()
        
        if user=='cesavila':
            print "\n\nIm in\n\n"
            if "bot log" in in_message:
                f = open('log.txt', 'r+')
                bot_log = f.read()
                sendSparkPOST("https://api.ciscospark.com/v1/messages", {"roomId": webhook['data']['roomId'], "markdown": bot_log })
                f.close()            

            elif "bot request" in in_message:
                f = open('request.txt', 'r+')
                bot_request = f.read()
                sendSparkPOST("https://api.ciscospark.com/v1/messages", {"roomId": webhook['data']['roomId'], "text": bot_request })
                f.close()                

            elif "bot backup" in in_message:
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], "cxcollab-bot.py", "cxcollab-bot.py", "cxcollab-bot.py", 'doc/docx')
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], "cxcollab BOT links.py", "links.py", "links.py", 'doc/docx')
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], "cxcollab BOT log.txt", "log.txt", "log.txt", 'doc/docx')
                sendSparkPOST_file("https://api.ciscospark.com/v1/messages", webhook['data']['roomId'], "cxcollab BOT request.txt", "request.txt", "request.txt", 'image/gif')
                f.close()


    return "true"



####BOT Details#####
bot_email = "cxcollab@sparkbot.io"
bot_name = "cxcollab"
bearer = "Bearer OWU5MWY2MjItZjg3NC00ZWQ3LTlhMjktY2ZmN2Q0ZTM2ODlmMTY5ZmJiYjEtNDhi_PF84_1eb65fdf-9643-417f-9974-ad72cae0e10f"
cisco_support  = "https://www.cisco.com/c/en/us/support/index.html"
run_itty(server='wsgiref', host='0.0.0.0', port=8443)
# application/vnd.openxmlformats-officedocument.presentationml.presentation
# application/vnd.openxmlformats-officedocument.wordprocessingml.document
# application/pdf
#curl -X GET -H "Authorization: Bearer ZTI5ZGU1OTYtMGQ1Ny00MDFiLThkZTMtOWU3MTNjMjFlYjgxMjA1N2I3NGUtMjVl_PF84_1eb65fdf-9643-417f-9974-ad72cae0e10f" -H "Content-type: application/json" -H "Accept: application/json"  "https://api.ciscospark.com/v1/messages/Y2lzY29zcGFyazovL3VzL01FU1NBR0UvZWY4MDkwNTAtNzgxNC0xMWU5LWJhMTAtMjdlMjRjY2VlNDE5"


