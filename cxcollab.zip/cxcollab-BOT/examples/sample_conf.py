# itty Config
host = 'localhost'
port = 8080
server = 'wsgiref'